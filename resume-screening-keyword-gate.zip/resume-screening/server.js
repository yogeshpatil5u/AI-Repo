// Resume Screening — local server
// Serves the web app, handles sign-in and user management, and proxies analysis
// requests to OpenRouter (default: NVIDIA Nemotron 3 Ultra), OmniRoute, Groq, Claude or Sarvam AI. No dependencies: requires Node.js 18+.

const http = require("http");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const https = require("https");
const tls = require("tls");

// ---- load .env (simple KEY=VALUE parser) ----
const envPath = path.join(__dirname, ".env");
if (fs.existsSync(envPath)) {
  for (const line of fs.readFileSync(envPath, "utf8").split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/i);
    if (!m || line.trim().startsWith("#")) continue;
    const v = m[2].replace(/^["']|["']$/g, "");
    if (process.env[m[1]] === undefined) process.env[m[1]] = v;
  }
}

const PORT = Number(process.env.PORT || 3000);
const HOST = process.env.HOST || "127.0.0.1";
// ---- AI provider: "openrouter" (default), "omniroute", "groq", "anthropic" (Claude) or "sarvam" ----
const PROVIDER_ID = (() => {
  const v = (process.env.AI_PROVIDER || "").trim().toLowerCase();
  if (["openrouter", "omniroute", "groq", "anthropic", "sarvam"].includes(v)) return v;
  if (v === "claude") return "anthropic";
  if (process.env.OPENROUTER_API_KEY) return "openrouter";
  if (process.env.OMNIROUTE_BASE_URL || process.env.OMNIROUTE_API_KEY) return "omniroute";
  if (process.env.GROQ_API_KEY) return "groq";
  if (process.env.ANTHROPIC_API_KEY) return "anthropic";
  if (process.env.SARVAM_API_KEY) return "sarvam";
  return "openrouter";
})();
const IS_OPENAI = PROVIDER_ID !== "anthropic";          // OpenRouter, OmniRoute, Groq and Sarvam use the OpenAI-style chat completions API
const effortEnv = (name, dflt) => { const v = process.env[name]; return (v === undefined ? dflt : v).trim().toLowerCase(); };
// OmniRoute base URL may be given with or without the trailing /v1
const omniBase = (process.env.OMNIROUTE_BASE_URL || "http://localhost:20128/v1").replace(/\/+$/, "");
const OR_MODEL = process.env.OPENROUTER_MODEL || "nvidia/nemotron-3-ultra-550b-a55b";
const PROVIDERS = {
  openrouter: {
    name: "OpenRouter", keyVar: "OPENROUTER_API_KEY",
    url: (process.env.OPENROUTER_BASE_URL || "https://openrouter.ai/api").replace(/\/+$/, "").replace(/\/v1$/, "") + "/v1/chat/completions",
    headers: k => ({ authorization: "Bearer " + k,
      "http-referer": process.env.OPENROUTER_SITE_URL || "http://localhost:3000",   // optional OpenRouter app attribution
      "x-title": process.env.OPENROUTER_APP_NAME || "Resume Screening" }),
    // Optional: only route to providers that support every parameter sent (JSON mode, reasoning)
    extra: /^(1|true|yes)$/i.test(process.env.OPENROUTER_REQUIRE_PARAMETERS || "") ? { provider: { require_parameters: true } } : {},
    effortStyle: "openrouter",   // OpenRouter's unified { reasoning: { effort, exclude } }
    // NVIDIA Nemotron 3 Ultra (550B total / 55B active, hybrid reasoning model)
    tiers: {
      default: { model: process.env.MODEL_STANDARD || OR_MODEL, effort: effortEnv("EFFORT_STANDARD", "medium") },
      complex: { model: process.env.MODEL_THOROUGH || OR_MODEL, effort: effortEnv("EFFORT_THOROUGH", "high") },
      quick:   { model: process.env.MODEL_FAST || OR_MODEL,     effort: effortEnv("EFFORT_FAST", "low") },
    },
    maxTokens: 16000, batchSize: 3,
  },
  omniroute: {
    name: "OmniRoute", keyVar: "OMNIROUTE_API_KEY", keyOptional: true,
    url: (/\/v1$/.test(omniBase) ? omniBase : omniBase + "/v1") + "/chat/completions",
    headers: k => (k ? { authorization: "Bearer " + k } : {}),
    extra: {},
    // "auto" lets OmniRoute pick a healthy provider; use a combo name or provider/model to pin one.
    tiers: {
      default: { model: process.env.MODEL_STANDARD || process.env.OMNIROUTE_MODEL || "auto", effort: effortEnv("EFFORT_STANDARD", "") },
      complex: { model: process.env.MODEL_THOROUGH || process.env.OMNIROUTE_MODEL || "auto", effort: effortEnv("EFFORT_THOROUGH", "") },
      quick:   { model: process.env.MODEL_FAST || process.env.OMNIROUTE_MODEL || "auto",     effort: effortEnv("EFFORT_FAST", "") },
    },
    maxTokens: 8000, batchSize: 2,
  },
  groq: {
    name: "Groq", keyVar: "GROQ_API_KEY",
    url: (process.env.GROQ_BASE_URL || "https://api.groq.com/openai").replace(/\/$/, "") + "/v1/chat/completions",
    headers: k => ({ authorization: "Bearer " + k }),
    extra: { include_reasoning: false },               // GPT-OSS: keep reasoning out of the reply
    tiers: {
      default: { model: process.env.MODEL_STANDARD || process.env.GROQ_MODEL || "openai/gpt-oss-120b", effort: effortEnv("EFFORT_STANDARD", "medium") },
      complex: { model: process.env.MODEL_THOROUGH || process.env.GROQ_MODEL || "openai/gpt-oss-120b", effort: effortEnv("EFFORT_THOROUGH", "high") },
      quick:   { model: process.env.MODEL_FAST || "openai/gpt-oss-20b", effort: effortEnv("EFFORT_FAST", "low") },
    },
    maxTokens: 8000, batchSize: 2,
  },
  anthropic: {
    name: "Claude (Anthropic)", keyVar: "ANTHROPIC_API_KEY",
    url: (process.env.ANTHROPIC_BASE_URL || "https://api.anthropic.com").replace(/\/$/, "") + "/v1/messages",
    tiers: {
      default: { model: process.env.MODEL_STANDARD || "claude-sonnet-4-5", effort: "" },
      complex: { model: process.env.MODEL_THOROUGH || "claude-opus-4-5",   effort: "" },
      quick:   { model: process.env.MODEL_FAST || "claude-haiku-4-5",      effort: "" },
    },
    maxTokens: 16000, batchSize: 4,
  },
  sarvam: {
    name: "Sarvam AI", keyVar: "SARVAM_API_KEY",
    url: (process.env.SARVAM_BASE_URL || "https://api.sarvam.ai").replace(/\/$/, "") + "/v1/chat/completions",
    headers: k => ({ "api-subscription-key": k, authorization: "Bearer " + k }),
    extra: {},
    tiers: {
      default: { model: process.env.MODEL_STANDARD || process.env.SARVAM_MODEL || "sarvam-105b", effort: effortEnv("EFFORT_STANDARD", "") },
      complex: { model: process.env.MODEL_THOROUGH || process.env.SARVAM_MODEL || "sarvam-105b", effort: effortEnv("EFFORT_THOROUGH", "high") },
      quick:   { model: process.env.MODEL_FAST || process.env.SARVAM_MODEL || "sarvam-105b",     effort: effortEnv("EFFORT_FAST", "low") },
    },
    maxTokens: 16000, batchSize: 4,
  },
};
const P = PROVIDERS[PROVIDER_ID];
const PROVIDER = P.name;
const KEY_VAR = P.keyVar;
const API_KEY = process.env[KEY_VAR] || "";
const API_URL = P.url;
const TIERS = P.tiers;
const tierLabel = t => t.model + (t.effort ? ` (${t.effort} reasoning)` : "");
const MODELS = Object.fromEntries(Object.entries(TIERS).map(([k, t]) => [k, tierLabel(t)]));
const MAX_TOKENS = Number(process.env.MAX_TOKENS || P.maxTokens);
const BATCH_SIZE = Math.max(1, Math.min(8, Number(process.env.BATCH_SIZE || P.batchSize)));
const TEMPERATURE = Number(process.env.TEMPERATURE || 0.2);
// Domain gate: resumes need projects in these domains; others are rejected
const TARGET_DOMAINS = (process.env.TARGET_DOMAINS || "Storage,Networking,Security,Cloud,Semiconductors,IoT,Virtualization,Infrastructure")
  .split(",").map(x => x.trim()).filter(Boolean);
const DOMAIN_FILTER = !/^(0|false|no|off)$/i.test(process.env.DOMAIN_FILTER || "true");
// Keyword gate: JD keywords must appear in project details (all must-haves + a minimum share of all keywords)
const KEYWORD_GATE = !/^(0|false|no|off)$/i.test(process.env.KEYWORD_GATE || "true");
const KEYWORD_MIN_COVERAGE = Math.max(0, Math.min(100, Number(process.env.KEYWORD_MIN_COVERAGE ?? 50) || 0));
let JSON_MODE = !/^(0|false|no)$/i.test(process.env.JSON_MODE || "true");
const MAX_BODY = 2 * 1024 * 1024;
const REQUEST_TIMEOUT_MS = Number(process.env.REQUEST_TIMEOUT_SECONDS || 600) * 1000;
// Corporate SSL inspection: trust an extra root certificate (PEM file)
const EXTRA_CA_FILE = process.env.EXTRA_CA_CERTS || "";
let EXTRA_CA = null;
if (EXTRA_CA_FILE) {
  try { EXTRA_CA = [...tls.rootCertificates, fs.readFileSync(path.resolve(__dirname, EXTRA_CA_FILE), "utf8")]; console.log("Trusting extra CA certificate from " + EXTRA_CA_FILE); }
  catch (e) { console.error("Could not read EXTRA_CA_CERTS file " + EXTRA_CA_FILE + ": " + e.message); }
}

// =====================================================================
// Outbound HTTPS with optional proxy (HTTPS_PROXY / NO_PROXY) — no dependencies
// =====================================================================
function proxyFor(url) {
  const raw = process.env.HTTPS_PROXY || process.env.https_proxy || process.env.HTTP_PROXY || process.env.http_proxy || "";
  if (!raw) return null;
  const noProxy = (process.env.NO_PROXY || process.env.no_proxy || "").split(",").map(x => x.trim().toLowerCase()).filter(Boolean);
  const host = url.hostname.toLowerCase();
  if (host === "localhost" || host === "::1" || host === "[::1]" || /^127\./.test(host) || host === "host.docker.internal") return null;
  if (noProxy.some(n => n === "*" || host === n.replace(/^\./, "") || host.endsWith(n.startsWith(".") ? n : "." + n))) return null;
  try { return new URL(/^[a-z]+:\/\//i.test(raw) ? raw : "http://" + raw); } catch { return null; }
}
function postJson(urlStr, headers, bodyObj, signal) {
  return new Promise((resolve, reject) => {
    const url = new URL(urlStr);
    const body = Buffer.from(JSON.stringify(bodyObj));
    const isHttps = url.protocol === "https:";
    const port = Number(url.port || (isHttps ? 443 : 80));
    const reqHeaders = { ...headers, "content-length": body.length, host: url.host };
    let done = false, active = null;
    const fail = e => { if (!done) { done = true; reject(e); } };
    if (signal) signal.addEventListener("abort", () => { active?.destroy(); fail(Object.assign(new Error("aborted"), { code: "ABORTED" })); }, { once: true });

    const send = createConnection => {
      const mod = isHttps ? https : http;
      const req = mod.request({ hostname: url.hostname, port, path: url.pathname + url.search, method: "POST", headers: reqHeaders,
        ...(isHttps ? { servername: url.hostname, ...(EXTRA_CA ? { ca: EXTRA_CA } : {}) } : {}),
        ...(createConnection ? { createConnection, agent: false } : {}) }, res => {
        const chunks = [];
        res.on("data", c => chunks.push(c));
        res.on("end", () => {
          if (done) return; done = true;
          const text = Buffer.concat(chunks).toString("utf8");
          let json = null; try { json = JSON.parse(text); } catch {}
          resolve({ status: res.statusCode, ok: res.statusCode >= 200 && res.statusCode < 300, json, text });
        });
        res.on("error", fail);
      });
      active = req;
      req.setTimeout(REQUEST_TIMEOUT_MS, () => req.destroy(Object.assign(new Error("No reply within " + REQUEST_TIMEOUT_MS / 1000 + " seconds"), { code: "ETIMEDOUT" })));
      req.on("error", fail);
      req.end(body);
    };

    const proxy = proxyFor(url);
    if (!proxy) return send(null);
    // Tunnel through the proxy with CONNECT
    const proxyMod = proxy.protocol === "https:" ? https : http;
    const ph = { host: `${url.hostname}:${port}` };
    if (proxy.username) ph["proxy-authorization"] = "Basic " + Buffer.from(decodeURIComponent(proxy.username) + ":" + decodeURIComponent(proxy.password)).toString("base64");
    const creq = proxyMod.request({ hostname: proxy.hostname, port: Number(proxy.port || (proxy.protocol === "https:" ? 443 : 80)), method: "CONNECT", path: `${url.hostname}:${port}`, headers: ph });
    active = creq;
    creq.setTimeout(30000, () => creq.destroy(Object.assign(new Error("Proxy did not answer"), { code: "PROXY_TIMEOUT" })));
    creq.on("connect", (res, socket) => {
      if (res.statusCode !== 200) { socket.destroy(); return fail(Object.assign(new Error("Proxy refused the connection (HTTP " + res.statusCode + ")"), { code: res.statusCode === 407 ? "PROXY_AUTH" : "PROXY_REFUSED" })); }
      if (!isHttps) return send(() => socket);
      send(() => tls.connect({ socket, servername: url.hostname, ...(EXTRA_CA ? { ca: EXTRA_CA } : {}) }));
    });
    creq.on("error", e => fail(Object.assign(e, { viaProxy: proxy.host })));
    creq.end();
  });
}
function explainNetError(e, host) {
  const c = e.code || "";
  if (PROVIDER_ID === "omniroute" && (c === "ECONNREFUSED" || c === "ENOTFOUND" || c === "EAI_AGAIN"))
    return `OmniRoute isn't reachable at ${new URL(API_URL).origin} (${c}). Start it (npx omniroute, or docker run -p 20128:20128 diegosouzapw/omniroute) or fix OMNIROUTE_BASE_URL in .env. If this app runs in Docker and OmniRoute on the host, use http://host.docker.internal:20128/v1.`;
  if (c === "ENOTFOUND" || c === "EAI_AGAIN") return `The server can't look up ${host}. Check its DNS or internet access. If your network uses a proxy, set HTTPS_PROXY in .env.`;
  if (c === "ECONNREFUSED" || c === "ECONNRESET" || c === "ETIMEDOUT" && !/No reply/.test(e.message) || c === "ENETUNREACH" || c === "EHOSTUNREACH")
    return e.viaProxy ? `The server can't connect to the proxy ${e.viaProxy} (${c}). Check HTTPS_PROXY in .env.` : `The server can't connect to ${host} (${c}). A firewall is probably blocking it. If your network uses a proxy, set HTTPS_PROXY in .env.`;
  if (/No reply/.test(e.message)) return `${host} didn't reply within ${REQUEST_TIMEOUT_MS / 1000} seconds. Try Fast depth, fewer resumes, or raise REQUEST_TIMEOUT_SECONDS.`;
  if (c === "PROXY_AUTH") return "The proxy requires a username and password. Use HTTPS_PROXY=http://user:password@proxy-host:port in .env.";
  if (c === "PROXY_REFUSED" || c === "PROXY_TIMEOUT") return e.message + `. Ask IT to allow ${host} through the proxy.`;
  if (/CERT|certificate|SELF_SIGNED|UNABLE_TO_(GET|VERIFY)/i.test(c + " " + e.message))
    return `The connection to ${host} was blocked by a certificate check (${c || e.message}). Your network probably inspects HTTPS traffic. Get the company root certificate (PEM) from IT and set EXTRA_CA_CERTS=path/to/cert.pem in .env.`;
  return `Could not reach ${host}: ${e.message}${c ? " (" + c + ")" : ""}.`;
}
const DATA_DIR = path.resolve(__dirname, process.env.DATA_DIR || "data");
const USERS_FILE = path.join(DATA_DIR, "users.json");
const SESSION_HOURS = Number(process.env.SESSION_HOURS || 12);
const SECURE_COOKIE = /^(1|true|yes)$/i.test(process.env.SECURE_COOKIE || "");
const PUBLIC_DIR = path.join(__dirname, "public");

const SYSTEM =
  "You are a technical recruitment analyst. Follow the user's evaluation instructions exactly. " +
  "Your reply is parsed by a program: respond with exactly one JSON object and nothing else — no Markdown fences, no commentary.";

const MIME = { ".html": "text/html; charset=utf-8", ".js": "text/javascript", ".css": "text/css", ".svg": "image/svg+xml", ".png": "image/png", ".ico": "image/x-icon" };

// =====================================================================
// Users (stored in data/users.json, passwords hashed with scrypt)
// =====================================================================
function hashPassword(pw, salt = crypto.randomBytes(16).toString("hex")) {
  const hash = crypto.scryptSync(String(pw), salt, 64).toString("hex");
  return { salt, hash };
}
function checkPassword(pw, user) {
  const h = crypto.scryptSync(String(pw), user.salt, 64);
  const stored = Buffer.from(user.hash, "hex");
  return stored.length === h.length && crypto.timingSafeEqual(stored, h);
}
function loadUsers() {
  try { return JSON.parse(fs.readFileSync(USERS_FILE, "utf8")); } catch { return null; }
}
function saveUsers(users) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  const tmp = USERS_FILE + ".tmp";
  fs.writeFileSync(tmp, JSON.stringify(users, null, 2), { mode: 0o600 });
  fs.renameSync(tmp, USERS_FILE);
}
let USERS = loadUsers();
if (!USERS || !Array.isArray(USERS.users) || !USERS.users.length) {
  USERS = { users: [{ username: "admin", role: "admin", ...hashPassword("admin"), mustChangePassword: true, createdAt: new Date().toISOString() }] };
  saveUsers(USERS);
  console.log("Created default administrator: username 'admin', password 'admin' (must be changed at first sign-in).");
}
const findUser = name => USERS.users.find(u => u.username.toLowerCase() === String(name || "").toLowerCase());
const publicUser = u => ({ username: u.username, role: u.role, mustChangePassword: !!u.mustChangePassword, createdAt: u.createdAt, lastLogin: u.lastLogin || null });
const USERNAME_RE = /^[A-Za-z0-9._-]{3,32}$/;
const pwProblem = pw => (typeof pw !== "string" || pw.length < 8) ? "Password must be at least 8 characters." : (pw.toLowerCase() === "admin" ? "Choose a password other than 'admin'." : null);

// =====================================================================
// Sessions (in memory; everyone signs in again after a server restart)
// =====================================================================
const sessions = new Map(); // token -> { username, expires }
function createSession(username) {
  const token = crypto.randomBytes(32).toString("hex");
  sessions.set(token, { username, expires: Date.now() + SESSION_HOURS * 3600e3 });
  return token;
}
function getCookie(req, name) {
  const m = (req.headers.cookie || "").split(/;\s*/).find(c => c.startsWith(name + "="));
  return m ? decodeURIComponent(m.slice(name.length + 1)) : null;
}
function sessionUser(req) {
  const token = getCookie(req, "rs_session");
  const s = token && sessions.get(token);
  if (!s) return null;
  if (s.expires < Date.now()) { sessions.delete(token); return null; }
  const u = findUser(s.username);
  if (!u) { sessions.delete(token); return null; }
  return { token, user: u };
}
function cookieHeader(token, maxAgeSec) {
  return `rs_session=${token}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${maxAgeSec}${SECURE_COOKIE ? "; Secure" : ""}`;
}
function endSessionsFor(username, exceptToken) {
  for (const [t, s] of sessions) if (s.username.toLowerCase() === username.toLowerCase() && t !== exceptToken) sessions.delete(t);
}
setInterval(() => { const now = Date.now(); for (const [t, s] of sessions) if (s.expires < now) sessions.delete(t); }, 3600e3).unref();

// Simple sign-in throttling: 10 failed attempts per IP per 15 minutes
const failures = new Map();
function tooManyFailures(ip) {
  const f = failures.get(ip);
  if (!f || f.until < Date.now()) return false;
  return f.count >= 10;
}
function recordFailure(ip) {
  const f = failures.get(ip);
  if (!f || f.until < Date.now()) failures.set(ip, { count: 1, until: Date.now() + 15 * 60e3 });
  else f.count++;
}

// =====================================================================
// Helpers
// =====================================================================
function send(res, status, obj, headers = {}) {
  res.writeHead(status, { "Content-Type": "application/json", "Cache-Control": "no-store", ...headers });
  res.end(JSON.stringify(obj));
}
function redirect(res, to) { res.writeHead(302, { Location: to, "Cache-Control": "no-store" }); res.end(); }
function readBody(req) {
  return new Promise((resolve, reject) => {
    let size = 0; const chunks = [];
    req.on("data", c => { size += c.length; if (size > MAX_BODY) { reject(Object.assign(new Error("too large"), { code: "prompt_too_large" })); req.destroy(); } else chunks.push(c); });
    req.on("end", () => resolve(Buffer.concat(chunks).toString("utf8")));
    req.on("error", reject);
  });
}
async function readJson(req) {
  if (!/application\/json/i.test(req.headers["content-type"] || "")) throw Object.assign(new Error("Expected JSON"), { code: "invalid_request" });
  return JSON.parse((await readBody(req)) || "{}");
}
function parseJsonLoose(text) {
  const t = String(text || "").trim();
  try { return JSON.parse(t); } catch {}
  const fence = t.match(/```(?:json)?\s*([\s\S]*?)```/i);
  if (fence) { try { return JSON.parse(fence[1]); } catch {} }
  const a = t.indexOf("{"), b = t.lastIndexOf("}");
  if (a !== -1 && b > a) { try { return JSON.parse(t.slice(a, b + 1)); } catch {} }
  return undefined;
}
function serveFile(res, file, transform) {
  fs.readFile(file, (err, buf) => {
    if (err) { res.writeHead(404, { "Content-Type": "text/plain" }); return res.end("Not found"); }
    const ext = path.extname(file);
    let body = buf;
    if (transform) body = Buffer.from(transform(buf.toString("utf8")));
    res.writeHead(200, { "Content-Type": MIME[ext] || "application/octet-stream", "Cache-Control": ext === ".html" ? "no-store" : "public, max-age=300", "X-Frame-Options": "DENY" });
    res.end(body);
  });
}
const injectUser = u => html => html.replace("<!--RS_USER-->",
  `<script>window.RS_USER=${JSON.stringify(publicUser(u)).replace(/</g, "\\u003c")};</script>`);

// =====================================================================
// Auth + user API
// =====================================================================
async function handleLogin(req, res) {
  const ip = req.socket.remoteAddress || "?";
  if (tooManyFailures(ip)) return send(res, 429, { error: "Too many failed sign-in attempts. Try again in 15 minutes." });
  let b; try { b = await readJson(req); } catch { return send(res, 400, { error: "Bad request" }); }
  const u = findUser(b.username);
  if (!u || !checkPassword(b.password || "", u)) { recordFailure(ip); return send(res, 401, { error: "Incorrect username or password." }); }
  failures.delete(ip);
  u.lastLogin = new Date().toISOString(); saveUsers(USERS);
  const token = createSession(u.username);
  send(res, 200, { user: publicUser(u) }, { "Set-Cookie": cookieHeader(token, SESSION_HOURS * 3600) });
}

async function handleChangePassword(req, res, s) {
  let b; try { b = await readJson(req); } catch { return send(res, 400, { error: "Bad request" }); }
  if (!checkPassword(b.currentPassword || "", s.user)) return send(res, 400, { error: "Current password is incorrect." });
  const prob = pwProblem(b.newPassword); if (prob) return send(res, 400, { error: prob });
  Object.assign(s.user, hashPassword(b.newPassword), { mustChangePassword: false });
  saveUsers(USERS);
  endSessionsFor(s.user.username, s.token);
  send(res, 200, { user: publicUser(s.user) });
}

async function handleUsers(req, res, s, p) {
  if (s.user.role !== "admin") return send(res, 403, { error: "Only administrators can manage users." });
  if (s.user.mustChangePassword) return send(res, 403, { error: "Change your password first." });
  const admins = () => USERS.users.filter(u => u.role === "admin").length;

  if (p === "/api/users" && req.method === "GET") return send(res, 200, { users: USERS.users.map(publicUser) });

  if (p === "/api/users" && req.method === "POST") {
    let b; try { b = await readJson(req); } catch { return send(res, 400, { error: "Bad request" }); }
    const username = String(b.username || "").trim();
    if (!USERNAME_RE.test(username)) return send(res, 400, { error: "Username must be 3–32 characters: letters, numbers, dot, dash or underscore." });
    if (findUser(username)) return send(res, 409, { error: `User '${username}' already exists.` });
    const prob = pwProblem(b.password); if (prob) return send(res, 400, { error: prob });
    const role = b.role === "admin" ? "admin" : "user";
    const u = { username, role, ...hashPassword(b.password), mustChangePassword: b.mustChangePassword !== false, createdAt: new Date().toISOString(), createdBy: s.user.username };
    USERS.users.push(u); saveUsers(USERS);
    console.log(`[users] ${s.user.username} created ${role} '${username}'`);
    return send(res, 201, { user: publicUser(u) });
  }

  const m = p.match(/^\/api\/users\/([^/]+)(\/reset-password|\/role)?$/);
  if (m) {
    const target = findUser(decodeURIComponent(m[1]));
    if (!target) return send(res, 404, { error: "User not found." });
    const isSelf = target === s.user;

    if (!m[2] && req.method === "DELETE") {
      if (isSelf) return send(res, 400, { error: "You can't delete your own account." });
      if (target.role === "admin" && admins() <= 1) return send(res, 400, { error: "At least one administrator must remain." });
      USERS.users = USERS.users.filter(u => u !== target); saveUsers(USERS);
      endSessionsFor(target.username);
      console.log(`[users] ${s.user.username} deleted '${target.username}'`);
      return send(res, 200, { ok: true });
    }
    if (m[2] === "/reset-password" && req.method === "POST") {
      let b; try { b = await readJson(req); } catch { return send(res, 400, { error: "Bad request" }); }
      const prob = pwProblem(b.password); if (prob) return send(res, 400, { error: prob });
      Object.assign(target, hashPassword(b.password), { mustChangePassword: !isSelf });
      saveUsers(USERS); endSessionsFor(target.username, isSelf ? s.token : null);
      console.log(`[users] ${s.user.username} reset password for '${target.username}'`);
      return send(res, 200, { user: publicUser(target) });
    }
    if (m[2] === "/role" && req.method === "POST") {
      let b; try { b = await readJson(req); } catch { return send(res, 400, { error: "Bad request" }); }
      const role = b.role === "admin" ? "admin" : "user";
      if (target.role === "admin" && role !== "admin" && admins() <= 1) return send(res, 400, { error: "At least one administrator must remain." });
      target.role = role; saveUsers(USERS);
      return send(res, 200, { user: publicUser(target) });
    }
  }
  send(res, 404, { error: "Not found" });
}

// =====================================================================
// Analysis proxy
// =====================================================================
// Calls the configured provider. Returns the raw HTTP result {status, ok, json, text}.
async function callAI(tier, prompt, maxTokens, signal, opts = {}) {
  if (!IS_OPENAI) {
    return postJson(API_URL, { "content-type": "application/json", "x-api-key": API_KEY, "anthropic-version": "2023-06-01" },
      { model: tier.model, max_tokens: maxTokens, temperature: TEMPERATURE, system: SYSTEM, messages: [{ role: "user", content: prompt }] }, signal);
  }
  // Groq / Sarvam chat completions (OpenAI-compatible). Drops optional parameters
  // (JSON mode, reasoning_effort, provider extras) if the API rejects them for the chosen model.
  const headers = { "content-type": "application/json", ...P.headers(API_KEY) };
  let useJson = opts.json !== false && JSON_MODE, useEffort = !!tier.effort;
  for (let attempt = 0; attempt < 4; attempt++) {
    const body = { model: tier.model, max_tokens: maxTokens, temperature: TEMPERATURE,
      messages: [{ role: "system", content: SYSTEM }, { role: "user", content: prompt }], ...(tier.noExtra ? {} : P.extra) };
    if (useJson) body.response_format = { type: "json_object" };
    if (useEffort) { if (P.effortStyle === "openrouter") body.reasoning = { effort: tier.effort, exclude: true }; else body.reasoning_effort = tier.effort; }
    const r = await postJson(API_URL, headers, body, signal);
    // Some gateways (e.g. OpenRouter) can answer HTTP 200 with an error body and no choices
    if (r.ok && r.json?.error && !Array.isArray(r.json?.choices)) { r.ok = false; r.status = Number(r.json.error.code) || 502; }
    if (r.ok || ![400, 422].includes(r.status)) return r;
    const m = JSON.stringify(r.json?.error || r.json?.detail || r.text || "");
    if (useJson && /response_format|json_object/i.test(m)) { useJson = false; JSON_MODE = false; console.warn("[ai] JSON mode not accepted; turning it off and retrying"); continue; }
    if (!tier.noExtra && Object.keys(P.extra).some(k => m.includes(k))) { tier.noExtra = true; console.warn(`[ai] ${tier.model} doesn't accept ${Object.keys(P.extra).join(", ")}; leaving it out from now on`); continue; }
    if (useEffort && /reasoning_effort|"reasoning"|reasoning\b/i.test(m)) { useEffort = false; console.warn(`[ai] reasoning setting '${tier.effort}' not accepted by ${tier.model}; using the model default from now on`); tier.effort = ""; continue; }
    return r;
  }
}
function apiErrorMessage(r) {
  const e = r.json?.error, d = r.json?.detail;
  const m = (e && (e.message || (typeof e === "string" ? e : ""))) || (typeof d === "string" ? d : Array.isArray(d) ? d.map(x => x.msg || JSON.stringify(x)).join("; ") : "") || r.json?.message;
  return m || ("HTTP " + r.status + (r.json ? "" : " from " + new URL(API_URL).hostname + ` (the reply did not come from the ${PROVIDER} API — a proxy or gateway may be blocking it)`));
}
// Extra guidance for common OpenRouter problems
function openRouterHint(r, msg) {
  const free = /:free\b/.test(OR_MODEL) || Object.values(TIERS).some(t => /:free\b/.test(t.model));
  if (r.status === 401) return msg + " Check OPENROUTER_API_KEY (create keys at openrouter.ai/settings/keys).";
  if (r.status === 402 || /credit|insufficient|payment/i.test(msg)) return msg + " Add credits at openrouter.ai/settings/credits, raise the key's credit limit, or switch to the free model (nvidia/nemotron-3-ultra-550b-a55b:free).";
  if (r.status === 404 || /no endpoints|not a valid model|model.*not found/i.test(msg))
    return msg + " Check the model ID in .env (OPENROUTER_MODEL / MODEL_*). If the ID is right, your OpenRouter privacy settings may block every provider for this model" + (free ? ": free models need prompt logging/training allowed at openrouter.ai/settings/privacy." : ": review openrouter.ai/settings/privacy.");
  if (r.status === 429 || /rate.?limit/i.test(msg)) return msg + (free ? " Free models have small per-minute and per-day limits: wait, set BATCH_SIZE=1, or use the paid model ID without :free." : " Wait a minute, or lower BATCH_SIZE.");
  if (r.status === 408 || r.status === 502 || r.status === 503) return msg + " The upstream provider for this model failed or timed out. Run again; OpenRouter may route to another provider.";
  return msg;
}
// Extra guidance for common OmniRoute set-up problems
function omniHint(r, msg) {
  if (PROVIDER_ID === "openrouter") return openRouterHint(r, msg);
  if (PROVIDER_ID !== "omniroute") return msg;
  const dash = new URL(API_URL).origin + "/dashboard";
  if (r.status === 401 || r.status === 403)
    return msg + (API_KEY ? ` Check OMNIROUTE_API_KEY against the key in the OmniRoute dashboard (${dash}).` : ` OmniRoute requires an API key: create one in the OmniRoute dashboard (${dash}) and set OMNIROUTE_API_KEY in .env.`);
  if (r.status === 404 || /model.*(not found|unknown|does not exist)|no such (model|combo)/i.test(msg))
    return msg + ` Check the MODEL_ names in .env: use "auto", a combo name, or a provider/model ID listed at ${new URL(API_URL).origin}/v1/models.`;
  if (/no (available|healthy|eligible)?\s*(provider|account|connection)|not configured|all providers|exhausted|quota/i.test(msg) || r.status === 503)
    return msg + ` Connect at least one working provider (or add a fallback to your combo) in the OmniRoute dashboard (${dash}).`;
  return msg;
}
// Normalised reply: { text, truncated }
function replyOf(data) {
  if (!IS_OPENAI) {
    const text = (data?.content || []).filter(b => b.type === "text").map(b => b.text).join("").trim();
    return { text, truncated: data?.stop_reason === "max_tokens" };
  }
  const c = data?.choices?.[0]?.message?.content;
  const t = Array.isArray(c) ? c.map(x => x.text || "").join("") : String(c || "");
  return { text: t.replace(/<think>[\s\S]*?<\/think>/gi, "").trim(), truncated: data?.choices?.[0]?.finish_reason === "length" };
}

// Admin: check the connection to the AI provider with a tiny request for each depth setting
async function testConnection(req, res) {
  if (!API_KEY && !P.keyOptional) return send(res, 200, { ok: false, results: [], error: KEY_VAR + " is not set in .env." });
  const host = new URL(API_URL).hostname;
  const proxy = proxyFor(new URL(API_URL));
  const results = [];
  for (const [tier, t] of Object.entries(TIERS)) {
    const model = tierLabel(t);
    const t0 = Date.now();
    try {
      const r = await callAI(t, 'Reply with exactly this JSON: {"ok":true}', IS_OPENAI ? 2000 : 20);
      const msg = r.ok ? "OK" : omniHint(r, apiErrorMessage(r));
      results.push({ tier, model, ok: r.ok, status: r.status, message: msg, ms: Date.now() - t0 });
    } catch (e) {
      results.push({ tier, model, ok: false, status: 0, message: explainNetError(e, host), ms: Date.now() - t0 });
      break; // network problem affects every model
    }
  }
  send(res, 200, { ok: results.length === 3 && results.every(x => x.ok), apiHost: host, proxy: proxy ? proxy.host : null, extraCa: !!EXTRA_CA, results });
}

async function analyze(req, res) {
  if (!API_KEY && !P.keyOptional) return send(res, 500, { code: "no_api_key", error: KEY_VAR + " is not set" });
  let body;
  try { body = await readJson(req); }
  catch (e) { return send(res, e.code === "prompt_too_large" ? 413 : 400, { code: e.code || "invalid_request", error: "Bad request body" }); }
  const prompt = String(body.prompt || "");
  if (!prompt) return send(res, 400, { code: "invalid_request", error: "prompt is required" });
  const tier = TIERS[body.tier] || TIERS.default;
  const model = tierLabel(tier);

  const ctl = new AbortController();
  res.on("close", () => { if (!res.writableEnded) ctl.abort(); });

  let r, data;
  const t0 = Date.now();
  try {
    r = await callAI(tier, prompt, MAX_TOKENS, ctl.signal);
    data = r.json || {};
  } catch (e) {
    if (ctl.signal.aborted) return;
    const msg = explainNetError(e, new URL(API_URL).hostname);
    console.error(`[analyze] network error after ${Math.round((Date.now() - t0) / 1000)}s:`, e.code || "", e.message, "\n  ->", msg);
    return send(res, 502, { code: "network_upstream", error: msg });
  }
  if (!r.ok) {
    let msg = omniHint(r, apiErrorMessage(r));
    if (/tokens per minute|\bTPM\b|tokens per day|\bTPD\b|rate limit/i.test(msg)) msg += " Lower BATCH_SIZE (e.g. 1) and MAX_TOKENS (e.g. 4000) in .env, wait a minute, or move to a higher plan with your AI provider.";
    console.error(`[analyze] API error ${r.status} (${model}):`, msg);
    let code = "upstream_error";
    if (r.json?.error?.code === "json_validate_failed") code = "invalid_json";
    if (code === "invalid_json") {}
    else if (r.status === 401 || r.status === 403) code = "auth_error";
    else if (r.status === 429 || r.status === 529 || r.json?.error?.code === "rate_limit_exceeded" || /tokens per minute|tokens per day|\bTPM\b|\bTPD\b/i.test(msg)) code = "rate_limited";
    else if (r.status === 404 || /\bmodel\b/i.test(msg)) code = "model_error";
    else if (r.status === 413 || /too long|too large|context/i.test(msg)) code = "prompt_too_large";
    return send(res, r.status >= 500 ? 502 : r.status, { code, error: msg });
  }
  const { text, truncated } = replyOf(data);
  const result = parseJsonLoose(text);
  if (truncated && (result === undefined || !Array.isArray(result?.assessments))) {
    console.error(`[analyze] reply cut off at MAX_TOKENS=${MAX_TOKENS} (usage: ${JSON.stringify(data.usage || {})})`);
    return send(res, 502, { code: "truncated", error: `The reply was cut off at ${MAX_TOKENS} tokens. Raise MAX_TOKENS in .env, choose Fast depth, or analyze fewer resumes per run.` });
  }
  if (result === undefined) {
    console.error("[analyze] unparseable reply:", text.slice(0, 300));
    return send(res, 502, { code: "invalid_json", error: "Reply was not valid JSON" });
  }
  send(res, 200, { result, model, usage: data.usage });
}

// =====================================================================
// Router
// =====================================================================
async function route(req, res) {
  const p = new URL(req.url, "http://x").pathname;
  const M = req.method;

  // Public routes
  if (p === "/api/health" && M === "GET") return send(res, 200, { ok: true });
  if (p === "/api/login" && M === "POST") return handleLogin(req, res);
  if (p === "/login" || p === "/login.html") {
    const cur = sessionUser(req);
    if (cur && !cur.user.mustChangePassword) return redirect(res, "/");
    return serveFile(res, path.join(PUBLIC_DIR, "login.html"));
  }
  if (p === "/api/logout" && M === "POST") {
    const t = getCookie(req, "rs_session"); if (t) sessions.delete(t);
    return send(res, 200, { ok: true }, { "Set-Cookie": cookieHeader("", 0) });
  }

  // Everything below needs a signed-in user
  const s = sessionUser(req);
  if (!s) return p.startsWith("/api/") ? send(res, 401, { code: "signed_out", error: "Please sign in." }) : redirect(res, "/login");

  if (p === "/api/me" && M === "GET") return send(res, 200, { user: publicUser(s.user), apiKey: !!API_KEY || !!P.keyOptional, provider: PROVIDER, keyVar: KEY_VAR, models: Object.fromEntries(Object.entries(TIERS).map(([k, t]) => [k, tierLabel(t)])), batchSize: BATCH_SIZE, targetDomains: TARGET_DOMAINS, domainFilter: DOMAIN_FILTER, keywordGate: KEYWORD_GATE, keywordMinCoverage: KEYWORD_MIN_COVERAGE });
  if (p === "/api/change-password" && M === "POST") return handleChangePassword(req, res, s);

  // Must change the default / reset password before using anything else
  if (s.user.mustChangePassword) return p.startsWith("/api/") ? send(res, 403, { code: "must_change_password", error: "Change your password first." }) : redirect(res, "/login?change=1");

  if (p.startsWith("/api/users")) return handleUsers(req, res, s, p);
  if (p === "/api/analyze" && M === "POST") return analyze(req, res);
  if (p === "/api/test-connection" && M === "POST") {
    if (s.user.role !== "admin") return send(res, 403, { error: "Only administrators can run the connection test." });
    return testConnection(req, res);
  }

  if (M !== "GET") { res.writeHead(405); return res.end(); }
  if (p === "/" || p === "/index.html") return serveFile(res, path.join(PUBLIC_DIR, "index.html"), injectUser(s.user));
  if (p === "/admin" || p === "/admin.html") {
    if (s.user.role !== "admin") return redirect(res, "/");
    return serveFile(res, path.join(PUBLIC_DIR, "admin.html"), injectUser(s.user));
  }
  const file = path.join(PUBLIC_DIR, decodeURIComponent(p).replace(/^\/+/, ""));
  if (!file.startsWith(PUBLIC_DIR + path.sep)) { res.writeHead(403); return res.end("Forbidden"); }
  serveFile(res, file);
}

http.createServer((req, res) => {
  route(req, res).catch(e => { console.error(e); if (!res.headersSent) send(res, 500, { code: "upstream_error", error: "Server error" }); });
}).listen(PORT, HOST, () => {
  console.log(`Resume Screening running at http://${HOST === "0.0.0.0" ? "localhost" : HOST}:${PORT}`);
  console.log(`User accounts are stored in ${USERS_FILE}`);
  console.log(`Domain gate: ${DOMAIN_FILTER ? "ON" : "OFF"} — target domains: ${TARGET_DOMAINS.join(", ")}`);
  console.log(`Keyword gate: ${KEYWORD_GATE ? "ON" : "OFF"} — all must-have JD keywords + at least ${KEYWORD_MIN_COVERAGE}% of keywords in project details`);
  console.log(`AI provider: ${PROVIDER} (${API_URL}) — standard: ${MODELS.default}; thorough: ${MODELS.complex}; fast: ${MODELS.quick}; ${BATCH_SIZE} resume(s) per request, max ${MAX_TOKENS} reply tokens`);
  if (!API_KEY && !P.keyOptional) console.warn(`WARNING: ${KEY_VAR} is not set. Copy .env.example to .env and add your key.`);
  if (!API_KEY && P.keyOptional) console.log(`${KEY_VAR} not set: calling ${PROVIDER} without a key (set one if your gateway requires API keys).`);
});
