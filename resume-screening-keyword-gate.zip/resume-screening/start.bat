@echo off
cd /d "%~dp0"
if not exist .env (
  copy .env.example .env >nul
  echo Created .env - open it, add your OPENROUTER_API_KEY, then run start.bat again.
  pause
  exit /b 1
)
node server.js
pause
