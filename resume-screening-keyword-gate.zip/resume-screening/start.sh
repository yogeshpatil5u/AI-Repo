#!/usr/bin/env sh
cd "$(dirname "$0")"
[ -f .env ] || { cp .env.example .env; echo "Created .env - add your OPENROUTER_API_KEY, then run this again."; exit 1; }
node server.js
