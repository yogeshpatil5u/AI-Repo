# Resume Screening

Upload job descriptions and resumes (PDF, DOCX, TXT, MD). The AI places every candidate in
**Best Fit**, **Close to JD** or **Not Fit**, with key strengths, gaps (trainable vs. fundamental),
a one-sentence rationale and a 0–100 match score. Export a **PDF report**, a CSV file, or copy the report as text.

**Project evidence check:** for 6–10 key JD keywords, the app checks whether each one appears in the
resume's *project details* (project descriptions and work-experience bullets), what the candidate actually
did with it there, and classifies it as **Hands-on**, **Supporting**, **Mentioned only** (skills list with no
project backing) or **Not found**. Must-haves that are only listed, with no project behind them, count against the fit.

**Domain gate (infra focus):** every project in a resume is classified by the domain of the product or system
worked on. Target domains: **Storage, Networking, Security, Cloud, Semiconductors, IoT, Virtualization and
Infrastructure** (data centre, servers, OS/kernel, HPC, backup/DR, telecom, infra firmware, platform engineering).
- **In domain** (at least half the projects in target domains): assessed normally.
- **Partially in domain** (some, but fewer than half): capped at **Close to JD**.
- **Out of domain** (no projects in target domains): **rejected** as Not Fit, whatever the skills match.
The rule is applied by the app after the AI's assessment, so it is enforced consistently. Each card shows a
**Domain check** table; the PDF, CSV and text report include it. Change the list with `TARGET_DOMAINS`, or set
`DOMAIN_FILTER=false` to show the check without rejecting anyone.

**Keyword gate (JD keywords in project details):** a resume is selected only if its *project details* back up the JD:
- every **must-have JD keyword** appears in a project as Hands-on or Supporting work, and
- at least **50%** of all JD keywords do (`KEYWORD_MIN_COVERAGE`).
Keywords that appear only in a skills list or summary don't count. Resumes that fail are **rejected** (Not Fit) and the
card lists exactly which keywords were missing from projects. Set `KEYWORD_GATE=false` to show the check without rejecting.

**AI:** by default the app uses **NVIDIA Nemotron 3 Ultra** (`nvidia/nemotron-3-ultra-550b-a55b`) through
**OpenRouter**. OmniRoute, Groq, Claude (Anthropic) and Sarvam AI can be used instead (`AI_PROVIDER=omniroute|groq|anthropic|sarvam`).

## Requirements
- Node.js 18 or newer (no `npm install` needed — zero dependencies), **or** Docker
- An OpenRouter API key with credits (https://openrouter.ai/settings/keys) — this model costs roughly
  $0.50 per million input tokens and $2.20 per million output tokens at the time of writing
- Server access to `openrouter.ai` on port 443
- Browser access to `fonts.googleapis.com` and `cdnjs.cloudflare.com` (fonts and PDF/DOCX readers)

## Run with Node
1. Copy `.env.example` to `.env` and set `OPENROUTER_API_KEY`.
2. Start it:
   - Windows: double-click `start.bat`
   - macOS / Linux: `./start.sh`  (or `npm start`)
3. Open http://localhost:3000 and sign in with **admin / admin**. You must choose a new password at first sign-in.
4. As admin, click **Test connection** under the Run button.

## Run with Docker
```bash
cp .env.example .env      # then add your key
docker compose up -d --build
```
Open http://localhost:3000

## Nemotron 3 Ultra settings
- The three "Analysis depth" options all use Nemotron 3 Ultra with different reasoning effort:
  Standard `medium`, Thorough `high`, Fast `low` (`EFFORT_*`). Reasoning text is excluded from replies.
- Nemotron 3 Ultra is a large model: a Thorough run can take a few minutes per batch. Use Fast or Standard for quick screening.
- `BATCH_SIZE=3` resumes per request, `MAX_TOKENS=16000` (the smallest provider limit for this model is 16,384).
- **Free variant:** `OPENROUTER_MODEL=nvidia/nemotron-3-ultra-550b-a55b:free` costs nothing but has small
  per-minute/per-day limits and only works if you allow prompt logging/training in
  https://openrouter.ai/settings/privacy. Don't use it for real candidate resumes. If you do, set `BATCH_SIZE=1`.

## Sign-in and users
- First start creates the administrator **admin** with password **admin**. The first sign-in forces a password change.
- Administrators open **Users** (top right) to create users, reset passwords, change roles and delete users.
- Roles: **User** runs screenings. **Administrator** also manages users and runs Test connection.
- Accounts are stored in `data/users.json` (passwords are salted scrypt hashes). Back up this file.
- Locked out? Stop the server, delete `data/users.json` and start again. This resets to admin / admin and removes all other users.

## Configuration (`.env`)
| Variable | Default | Purpose |
|---|---|---|
| `AI_PROVIDER` | `openrouter` | `openrouter`, `omniroute`, `groq`, `anthropic` (Claude) or `sarvam` |
| `TARGET_DOMAINS` | Storage, Networking, Security, Cloud, Semiconductors, IoT, Virtualization, Infrastructure | Domains a candidate's projects must come from (comma-separated) |
| `DOMAIN_FILTER` | `true` | `false` = show the domain check but don't reject or cap anyone |
| `KEYWORD_GATE` | `true` | `false` = show the keyword check but don't reject anyone |
| `KEYWORD_MIN_COVERAGE` | `50` | % of all JD keywords that must appear in project details (must-haves are always required) |
| `OPENROUTER_API_KEY` | — | Required for OpenRouter |
| `OPENROUTER_MODEL` | `nvidia/nemotron-3-ultra-550b-a55b` | OpenRouter model ID (add `:free` for the free variant) |
| `OPENROUTER_REQUIRE_PARAMETERS` | `false` | `true` = only providers that support JSON mode and reasoning (excludes BaseTen) |
| `OPENROUTER_SITE_URL` / `OPENROUTER_APP_NAME` | localhost / Resume Screening | Optional attribution headers |
| `OMNIROUTE_BASE_URL`, `OMNIROUTE_API_KEY` | — | When `AI_PROVIDER=omniroute` |
| `MODEL_STANDARD` / `MODEL_THOROUGH` / `MODEL_FAST` | `OPENROUTER_MODEL` | Optional different model per "Analysis depth" option |
| `EFFORT_STANDARD` / `EFFORT_THOROUGH` / `EFFORT_FAST` | `medium` / `high` / `low` | Reasoning effort per option |
| `BATCH_SIZE` | `3` (OpenRouter), `2` (OmniRoute, Groq), `4` (others) | Resumes per request |
| `MAX_TOKENS` | `16000` (OpenRouter, Claude, Sarvam), `8000` (OmniRoute, Groq) | Max reply length per batch |
| `TEMPERATURE` | `0.2` | Lower = more consistent |
| `JSON_MODE` | `true` | Ask for JSON output; turns itself off if the model rejects it |
| `GROQ_API_KEY`, `ANTHROPIC_API_KEY`, `SARVAM_API_KEY` | — | Keys when using those providers directly |
| `PORT` | `3000` | Port to listen on |
| `HOST` | `127.0.0.1` | Use `0.0.0.0` to share on your network |
| `DATA_DIR` | `data` | Folder for `users.json` |
| `SESSION_HOURS` | `12` | How long a sign-in lasts |
| `SECURE_COOKIE` | `false` | Set `true` when served over HTTPS |
| `HTTPS_PROXY` / `NO_PROXY` | — | Company proxy for reaching a remote AI service (local addresses are never proxied) |
| `EXTRA_CA_CERTS` | — | Company root certificate (PEM) when HTTPS traffic is inspected |
| `REQUEST_TIMEOUT_SECONDS` | `600` | How long to wait for one batch |

## If analyses fail
Sign in as an administrator and click **Test connection**. It checks each depth option and says what is wrong:
- **No auth credentials / 401:** fix `OPENROUTER_API_KEY`.
- **Insufficient credits / 402:** add credits at openrouter.ai/settings/credits or raise the key's credit limit.
- **No endpoints found / 404:** check the model ID; for `:free` models allow prompt logging/training at openrouter.ai/settings/privacy.
- **Rate limit exceeded / 429:** wait; on the free variant set `BATCH_SIZE=1` or use the paid model.
- **Provider returned error / 502:** the upstream provider failed; run again.
- **OmniRoute isn't reachable:** start OmniRoute, or fix `OMNIROUTE_BASE_URL`. From Docker, use `http://host.docker.internal:20128/v1`.
- **OmniRoute requires an API key:** create a key in the OmniRoute dashboard and set `OMNIROUTE_API_KEY`.
- **No available provider:** connect at least one working provider in the OmniRoute dashboard, or add a fallback to your combo.
- **Model ... not found:** fix the `MODEL_` names — use `auto`, a combo name, or an ID from `/v1/models`.
- **Token / rate-limit errors:** set `BATCH_SIZE=1` and `MAX_TOKENS=4000`, or route to a provider with higher limits.
- **Failed to generate JSON / unreadable format:** run again, or pin Standard/Thorough to a stronger model.
- **Blocked by a certificate check / proxy refused:** see `EXTRA_CA_CERTS` and `HTTPS_PROXY` (remote providers only).
- **HTTP 504 / 502 in the browser:** a proxy in front of this app (e.g. Nginx) timed out. Set its read timeout to 600 seconds.
The server console also prints each failure on lines starting with `[analyze]`.

## How it works
- `public/index.html` — the web app. Files are read in the browser; inputs and the last results are saved in the browser's local storage.
- `public/login.html`, `public/admin.html` — sign-in and user management pages.
- `public/vendor/` — jsPDF 2.5.1 and jsPDF-AutoTable 3.8.2, used to build the PDF report in the browser.
- `server.js` — handles sign-in and users, serves the app and forwards analysis requests to OpenRouter (or OmniRoute / Groq / Claude / Sarvam AI), keeping your API key on the server.
- Resumes are sent in batches per JD (`BATCH_SIZE`). Each resume is trimmed to 14,000 characters.

## Data and privacy
Resume text is sent to OpenRouter and on to the provider serving Nemotron 3 Ultra (currently DeepInfra, BaseTen or Venice).
Review OpenRouter's privacy settings (openrouter.ai/settings/privacy) — you can require providers that don't log or
train on prompts. The `:free` variant needs logging/training allowed, so avoid it for real candidates.
Nothing is stored on this server except user accounts.
Use the "Clear all" button (top right) to remove local copies from the browser.
Scanned (image-only) PDFs have no text layer: paste their text instead.
